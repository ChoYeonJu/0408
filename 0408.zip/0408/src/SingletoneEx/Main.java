package SingletoneEx;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Normal normal1 = new Normal();
		Normal normal2 = new Normal();
		
		Singleton singleton1 = Singleton.getInstance();
		Singleton singleton2 = Singleton.getInstance();

		if(normal1 == normal2) {
			System.out.println("nor1�� nor2�� ����");
		}
		else {
			System.out.println("nor1�� nor2�� �ٸ�");
		}
		
		if(singleton1 == singleton2) {
			System.out.println("sing1�� sing2 ����");
		}
		else {
			System.out.println("sing1�� sing2 �ٸ�");
		}
	}

}
