package SingletoneEx;

public class Normal {
	
	public Normal() {
		System.out.println("Normal Instance Created..");
	}

}
